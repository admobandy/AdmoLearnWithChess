﻿namespace Board
{
    partial class boardWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(boardWindow));
            this.board = new System.Windows.Forms.PictureBox();
            this.BQR = new System.Windows.Forms.PictureBox();
            this.BQN = new System.Windows.Forms.PictureBox();
            this.BQB = new System.Windows.Forms.PictureBox();
            this.BQQ = new System.Windows.Forms.PictureBox();
            this.BKK = new System.Windows.Forms.PictureBox();
            this.BKB = new System.Windows.Forms.PictureBox();
            this.BKN = new System.Windows.Forms.PictureBox();
            this.BKR = new System.Windows.Forms.PictureBox();
            this.BQP1 = new System.Windows.Forms.PictureBox();
            this.BQP2 = new System.Windows.Forms.PictureBox();
            this.BQP3 = new System.Windows.Forms.PictureBox();
            this.BQP4 = new System.Windows.Forms.PictureBox();
            this.BKP1 = new System.Windows.Forms.PictureBox();
            this.BKP2 = new System.Windows.Forms.PictureBox();
            this.BKP3 = new System.Windows.Forms.PictureBox();
            this.BKP4 = new System.Windows.Forms.PictureBox();
            this.WQR = new System.Windows.Forms.PictureBox();
            this.WQP1 = new System.Windows.Forms.PictureBox();
            this.WQN = new System.Windows.Forms.PictureBox();
            this.WQB = new System.Windows.Forms.PictureBox();
            this.WQQ = new System.Windows.Forms.PictureBox();
            this.WKK = new System.Windows.Forms.PictureBox();
            this.WKB = new System.Windows.Forms.PictureBox();
            this.WKN = new System.Windows.Forms.PictureBox();
            this.WKR = new System.Windows.Forms.PictureBox();
            this.WQP2 = new System.Windows.Forms.PictureBox();
            this.WQP3 = new System.Windows.Forms.PictureBox();
            this.WQP4 = new System.Windows.Forms.PictureBox();
            this.WKP1 = new System.Windows.Forms.PictureBox();
            this.WKP2 = new System.Windows.Forms.PictureBox();
            this.WKP3 = new System.Windows.Forms.PictureBox();
            this.WKP4 = new System.Windows.Forms.PictureBox();
            this.statusLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.board)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKP1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKP4)).BeginInit();
            this.SuspendLayout();
            // 
            // board
            // 
            this.board.Image = ((System.Drawing.Image)(resources.GetObject("board.Image")));
            this.board.Location = new System.Drawing.Point(24, 24);
            this.board.Name = "board";
            this.board.Size = new System.Drawing.Size(564, 514);
            this.board.TabIndex = 0;
            this.board.TabStop = false;
            this.board.Click += new System.EventHandler(this.board_Click);
            // 
            // BQR
            // 
            this.BQR.Image = ((System.Drawing.Image)(resources.GetObject("BQR.Image")));
            this.BQR.Location = new System.Drawing.Point(27, 23);
            this.BQR.Name = "BQR";
            this.BQR.Size = new System.Drawing.Size(64, 64);
            this.BQR.TabIndex = 1;
            this.BQR.TabStop = false;
            this.BQR.Click += new System.EventHandler(this.BQR_Click);
            // 
            // BQN
            // 
            this.BQN.Image = ((System.Drawing.Image)(resources.GetObject("BQN.Image")));
            this.BQN.Location = new System.Drawing.Point(98, 23);
            this.BQN.Name = "BQN";
            this.BQN.Size = new System.Drawing.Size(64, 64);
            this.BQN.TabIndex = 2;
            this.BQN.TabStop = false;
            this.BQN.Click += new System.EventHandler(this.BQN_Click);
            // 
            // BQB
            // 
            this.BQB.Image = ((System.Drawing.Image)(resources.GetObject("BQB.Image")));
            this.BQB.Location = new System.Drawing.Point(167, 23);
            this.BQB.Name = "BQB";
            this.BQB.Size = new System.Drawing.Size(64, 64);
            this.BQB.TabIndex = 3;
            this.BQB.TabStop = false;
            this.BQB.Click += new System.EventHandler(this.BQB_Click);
            // 
            // BQQ
            // 
            this.BQQ.Image = ((System.Drawing.Image)(resources.GetObject("BQQ.Image")));
            this.BQQ.Location = new System.Drawing.Point(237, 24);
            this.BQQ.Name = "BQQ";
            this.BQQ.Size = new System.Drawing.Size(64, 64);
            this.BQQ.TabIndex = 4;
            this.BQQ.TabStop = false;
            this.BQQ.Click += new System.EventHandler(this.BQQ_Click);
            // 
            // BKK
            // 
            this.BKK.Image = ((System.Drawing.Image)(resources.GetObject("BKK.Image")));
            this.BKK.Location = new System.Drawing.Point(308, 24);
            this.BKK.Name = "BKK";
            this.BKK.Size = new System.Drawing.Size(64, 64);
            this.BKK.TabIndex = 5;
            this.BKK.TabStop = false;
            this.BKK.Click += new System.EventHandler(this.BKK_Click);
            // 
            // BKB
            // 
            this.BKB.Image = ((System.Drawing.Image)(resources.GetObject("BKB.Image")));
            this.BKB.Location = new System.Drawing.Point(378, 24);
            this.BKB.Name = "BKB";
            this.BKB.Size = new System.Drawing.Size(64, 64);
            this.BKB.TabIndex = 6;
            this.BKB.TabStop = false;
            this.BKB.Click += new System.EventHandler(this.BKB_Click);
            // 
            // BKN
            // 
            this.BKN.Image = ((System.Drawing.Image)(resources.GetObject("BKN.Image")));
            this.BKN.Location = new System.Drawing.Point(448, 24);
            this.BKN.Name = "BKN";
            this.BKN.Size = new System.Drawing.Size(64, 64);
            this.BKN.TabIndex = 7;
            this.BKN.TabStop = false;
            this.BKN.Click += new System.EventHandler(this.BKN_Click);
            // 
            // BKR
            // 
            this.BKR.Image = ((System.Drawing.Image)(resources.GetObject("BKR.Image")));
            this.BKR.Location = new System.Drawing.Point(520, 24);
            this.BKR.Name = "BKR";
            this.BKR.Size = new System.Drawing.Size(64, 64);
            this.BKR.TabIndex = 8;
            this.BKR.TabStop = false;
            this.BKR.Click += new System.EventHandler(this.BKR_Click);
            // 
            // BQP1
            // 
            this.BQP1.Image = ((System.Drawing.Image)(resources.GetObject("BQP1.Image")));
            this.BQP1.Location = new System.Drawing.Point(27, 90);
            this.BQP1.Name = "BQP1";
            this.BQP1.Size = new System.Drawing.Size(64, 64);
            this.BQP1.TabIndex = 9;
            this.BQP1.TabStop = false;
            this.BQP1.Click += new System.EventHandler(this.BQP1_Click);
            // 
            // BQP2
            // 
            this.BQP2.Image = ((System.Drawing.Image)(resources.GetObject("BQP2.Image")));
            this.BQP2.Location = new System.Drawing.Point(98, 90);
            this.BQP2.Name = "BQP2";
            this.BQP2.Size = new System.Drawing.Size(64, 64);
            this.BQP2.TabIndex = 10;
            this.BQP2.TabStop = false;
            this.BQP2.Click += new System.EventHandler(this.BQP2_Click);
            // 
            // BQP3
            // 
            this.BQP3.Image = ((System.Drawing.Image)(resources.GetObject("BQP3.Image")));
            this.BQP3.Location = new System.Drawing.Point(168, 90);
            this.BQP3.Name = "BQP3";
            this.BQP3.Size = new System.Drawing.Size(64, 64);
            this.BQP3.TabIndex = 11;
            this.BQP3.TabStop = false;
            this.BQP3.Click += new System.EventHandler(this.BQP3_Click);
            // 
            // BQP4
            // 
            this.BQP4.Image = ((System.Drawing.Image)(resources.GetObject("BQP4.Image")));
            this.BQP4.Location = new System.Drawing.Point(238, 90);
            this.BQP4.Name = "BQP4";
            this.BQP4.Size = new System.Drawing.Size(64, 64);
            this.BQP4.TabIndex = 12;
            this.BQP4.TabStop = false;
            this.BQP4.Click += new System.EventHandler(this.BQP4_Click);
            // 
            // BKP1
            // 
            this.BKP1.Image = ((System.Drawing.Image)(resources.GetObject("BKP1.Image")));
            this.BKP1.Location = new System.Drawing.Point(308, 90);
            this.BKP1.Name = "BKP1";
            this.BKP1.Size = new System.Drawing.Size(64, 64);
            this.BKP1.TabIndex = 13;
            this.BKP1.TabStop = false;
            this.BKP1.Click += new System.EventHandler(this.BKP1_Click);
            // 
            // BKP2
            // 
            this.BKP2.Image = ((System.Drawing.Image)(resources.GetObject("BKP2.Image")));
            this.BKP2.Location = new System.Drawing.Point(378, 90);
            this.BKP2.Name = "BKP2";
            this.BKP2.Size = new System.Drawing.Size(64, 64);
            this.BKP2.TabIndex = 14;
            this.BKP2.TabStop = false;
            this.BKP2.Click += new System.EventHandler(this.BKP2_Click);
            // 
            // BKP3
            // 
            this.BKP3.Image = ((System.Drawing.Image)(resources.GetObject("BKP3.Image")));
            this.BKP3.Location = new System.Drawing.Point(448, 90);
            this.BKP3.Name = "BKP3";
            this.BKP3.Size = new System.Drawing.Size(64, 64);
            this.BKP3.TabIndex = 15;
            this.BKP3.TabStop = false;
            this.BKP3.Click += new System.EventHandler(this.BKP3_Click);
            // 
            // BKP4
            // 
            this.BKP4.Image = ((System.Drawing.Image)(resources.GetObject("BKP4.Image")));
            this.BKP4.Location = new System.Drawing.Point(520, 90);
            this.BKP4.Name = "BKP4";
            this.BKP4.Size = new System.Drawing.Size(64, 64);
            this.BKP4.TabIndex = 16;
            this.BKP4.TabStop = false;
            this.BKP4.Click += new System.EventHandler(this.BKP4_Click);
            // 
            // WQR
            // 
            this.WQR.Image = ((System.Drawing.Image)(resources.GetObject("WQR.Image")));
            this.WQR.Location = new System.Drawing.Point(27, 474);
            this.WQR.Name = "WQR";
            this.WQR.Size = new System.Drawing.Size(64, 64);
            this.WQR.TabIndex = 17;
            this.WQR.TabStop = false;
            this.WQR.Click += new System.EventHandler(this.WQR_Click);
            // 
            // WQP1
            // 
            this.WQP1.Image = ((System.Drawing.Image)(resources.GetObject("WQP1.Image")));
            this.WQP1.Location = new System.Drawing.Point(27, 408);
            this.WQP1.Name = "WQP1";
            this.WQP1.Size = new System.Drawing.Size(64, 64);
            this.WQP1.TabIndex = 18;
            this.WQP1.TabStop = false;
            this.WQP1.Click += new System.EventHandler(this.WQP1_Click);
            // 
            // WQN
            // 
            this.WQN.Image = ((System.Drawing.Image)(resources.GetObject("WQN.Image")));
            this.WQN.Location = new System.Drawing.Point(97, 474);
            this.WQN.Name = "WQN";
            this.WQN.Size = new System.Drawing.Size(64, 64);
            this.WQN.TabIndex = 19;
            this.WQN.TabStop = false;
            this.WQN.Click += new System.EventHandler(this.WQN_Click);
            // 
            // WQB
            // 
            this.WQB.Image = ((System.Drawing.Image)(resources.GetObject("WQB.Image")));
            this.WQB.Location = new System.Drawing.Point(168, 474);
            this.WQB.Name = "WQB";
            this.WQB.Size = new System.Drawing.Size(64, 64);
            this.WQB.TabIndex = 20;
            this.WQB.TabStop = false;
            this.WQB.Click += new System.EventHandler(this.WQB_Click);
            // 
            // WQQ
            // 
            this.WQQ.Image = ((System.Drawing.Image)(resources.GetObject("WQQ.Image")));
            this.WQQ.Location = new System.Drawing.Point(238, 474);
            this.WQQ.Name = "WQQ";
            this.WQQ.Size = new System.Drawing.Size(64, 64);
            this.WQQ.TabIndex = 21;
            this.WQQ.TabStop = false;
            this.WQQ.Click += new System.EventHandler(this.WQQ_Click);
            // 
            // WKK
            // 
            this.WKK.Image = ((System.Drawing.Image)(resources.GetObject("WKK.Image")));
            this.WKK.Location = new System.Drawing.Point(308, 474);
            this.WKK.Name = "WKK";
            this.WKK.Size = new System.Drawing.Size(64, 64);
            this.WKK.TabIndex = 22;
            this.WKK.TabStop = false;
            this.WKK.Click += new System.EventHandler(this.WKK_Click);
            // 
            // WKB
            // 
            this.WKB.Image = ((System.Drawing.Image)(resources.GetObject("WKB.Image")));
            this.WKB.Location = new System.Drawing.Point(378, 474);
            this.WKB.Name = "WKB";
            this.WKB.Size = new System.Drawing.Size(64, 64);
            this.WKB.TabIndex = 23;
            this.WKB.TabStop = false;
            this.WKB.Click += new System.EventHandler(this.WKB_Click);
            // 
            // WKN
            // 
            this.WKN.Image = ((System.Drawing.Image)(resources.GetObject("WKN.Image")));
            this.WKN.Location = new System.Drawing.Point(448, 474);
            this.WKN.Name = "WKN";
            this.WKN.Size = new System.Drawing.Size(64, 64);
            this.WKN.TabIndex = 24;
            this.WKN.TabStop = false;
            this.WKN.Click += new System.EventHandler(this.WKN_Click);
            // 
            // WKR
            // 
            this.WKR.Image = ((System.Drawing.Image)(resources.GetObject("WKR.Image")));
            this.WKR.Location = new System.Drawing.Point(518, 474);
            this.WKR.Name = "WKR";
            this.WKR.Size = new System.Drawing.Size(64, 64);
            this.WKR.TabIndex = 25;
            this.WKR.TabStop = false;
            this.WKR.Click += new System.EventHandler(this.WKR_Click);
            // 
            // WQP2
            // 
            this.WQP2.Image = ((System.Drawing.Image)(resources.GetObject("WQP2.Image")));
            this.WQP2.Location = new System.Drawing.Point(97, 408);
            this.WQP2.Name = "WQP2";
            this.WQP2.Size = new System.Drawing.Size(64, 64);
            this.WQP2.TabIndex = 26;
            this.WQP2.TabStop = false;
            this.WQP2.Click += new System.EventHandler(this.WQP2_Click);
            // 
            // WQP3
            // 
            this.WQP3.Image = ((System.Drawing.Image)(resources.GetObject("WQP3.Image")));
            this.WQP3.Location = new System.Drawing.Point(167, 408);
            this.WQP3.Name = "WQP3";
            this.WQP3.Size = new System.Drawing.Size(64, 64);
            this.WQP3.TabIndex = 27;
            this.WQP3.TabStop = false;
            this.WQP3.Click += new System.EventHandler(this.WQP3_Click);
            // 
            // WQP4
            // 
            this.WQP4.Image = ((System.Drawing.Image)(resources.GetObject("WQP4.Image")));
            this.WQP4.Location = new System.Drawing.Point(238, 408);
            this.WQP4.Name = "WQP4";
            this.WQP4.Size = new System.Drawing.Size(64, 64);
            this.WQP4.TabIndex = 28;
            this.WQP4.TabStop = false;
            this.WQP4.Click += new System.EventHandler(this.WQP4_Click);
            // 
            // WKP1
            // 
            this.WKP1.Image = ((System.Drawing.Image)(resources.GetObject("WKP1.Image")));
            this.WKP1.Location = new System.Drawing.Point(308, 408);
            this.WKP1.Name = "WKP1";
            this.WKP1.Size = new System.Drawing.Size(64, 64);
            this.WKP1.TabIndex = 29;
            this.WKP1.TabStop = false;
            this.WKP1.Click += new System.EventHandler(this.WKP1_Click);
            // 
            // WKP2
            // 
            this.WKP2.Image = ((System.Drawing.Image)(resources.GetObject("WKP2.Image")));
            this.WKP2.Location = new System.Drawing.Point(378, 408);
            this.WKP2.Name = "WKP2";
            this.WKP2.Size = new System.Drawing.Size(64, 64);
            this.WKP2.TabIndex = 30;
            this.WKP2.TabStop = false;
            this.WKP2.Click += new System.EventHandler(this.WKP2_Click);
            // 
            // WKP3
            // 
            this.WKP3.Image = ((System.Drawing.Image)(resources.GetObject("WKP3.Image")));
            this.WKP3.Location = new System.Drawing.Point(448, 408);
            this.WKP3.Name = "WKP3";
            this.WKP3.Size = new System.Drawing.Size(64, 64);
            this.WKP3.TabIndex = 31;
            this.WKP3.TabStop = false;
            this.WKP3.Click += new System.EventHandler(this.WKP3_Click);
            // 
            // WKP4
            // 
            this.WKP4.Image = ((System.Drawing.Image)(resources.GetObject("WKP4.Image")));
            this.WKP4.Location = new System.Drawing.Point(520, 408);
            this.WKP4.Name = "WKP4";
            this.WKP4.Size = new System.Drawing.Size(64, 64);
            this.WKP4.TabIndex = 32;
            this.WKP4.TabStop = false;
            this.WKP4.Click += new System.EventHandler(this.WKP4_Click);
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(42, 557);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(37, 13);
            this.statusLabel.TabIndex = 33;
            this.statusLabel.Text = "Status";
            // 
            // boardWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 606);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.WKP4);
            this.Controls.Add(this.WKP3);
            this.Controls.Add(this.WKP2);
            this.Controls.Add(this.WKP1);
            this.Controls.Add(this.WQP4);
            this.Controls.Add(this.WQP3);
            this.Controls.Add(this.WQP2);
            this.Controls.Add(this.WKR);
            this.Controls.Add(this.WKN);
            this.Controls.Add(this.WKB);
            this.Controls.Add(this.WKK);
            this.Controls.Add(this.WQQ);
            this.Controls.Add(this.WQB);
            this.Controls.Add(this.WQN);
            this.Controls.Add(this.WQP1);
            this.Controls.Add(this.WQR);
            this.Controls.Add(this.BKP4);
            this.Controls.Add(this.BKP3);
            this.Controls.Add(this.BKP2);
            this.Controls.Add(this.BKP1);
            this.Controls.Add(this.BQP4);
            this.Controls.Add(this.BQP3);
            this.Controls.Add(this.BQP2);
            this.Controls.Add(this.BQP1);
            this.Controls.Add(this.BKR);
            this.Controls.Add(this.BKN);
            this.Controls.Add(this.BKB);
            this.Controls.Add(this.BKK);
            this.Controls.Add(this.BQQ);
            this.Controls.Add(this.BQB);
            this.Controls.Add(this.BQN);
            this.Controls.Add(this.BQR);
            this.Controls.Add(this.board);
            this.Name = "boardWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chess Board";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.board)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BQP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BKP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WQP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKP1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WKP4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox board;
        private System.Windows.Forms.PictureBox BQR;
        private System.Windows.Forms.PictureBox BQN;
        private System.Windows.Forms.PictureBox BQB;
        private System.Windows.Forms.PictureBox BQQ;
        private System.Windows.Forms.PictureBox BKK;
        private System.Windows.Forms.PictureBox BKB;
        private System.Windows.Forms.PictureBox BKN;
        private System.Windows.Forms.PictureBox BKR;
        private System.Windows.Forms.PictureBox BQP1;
        private System.Windows.Forms.PictureBox BQP2;
        private System.Windows.Forms.PictureBox BQP3;
        private System.Windows.Forms.PictureBox BQP4;
        private System.Windows.Forms.PictureBox BKP1;
        private System.Windows.Forms.PictureBox BKP2;
        private System.Windows.Forms.PictureBox BKP3;
        private System.Windows.Forms.PictureBox BKP4;
        private System.Windows.Forms.PictureBox WQR;
        private System.Windows.Forms.PictureBox WQP1;
        private System.Windows.Forms.PictureBox WQN;
        private System.Windows.Forms.PictureBox WQB;
        private System.Windows.Forms.PictureBox WQQ;
        private System.Windows.Forms.PictureBox WKK;
        private System.Windows.Forms.PictureBox WKB;
        private System.Windows.Forms.PictureBox WKN;
        private System.Windows.Forms.PictureBox WKR;
        private System.Windows.Forms.PictureBox WQP2;
        private System.Windows.Forms.PictureBox WQP3;
        private System.Windows.Forms.PictureBox WQP4;
        private System.Windows.Forms.PictureBox WKP1;
        private System.Windows.Forms.PictureBox WKP2;
        private System.Windows.Forms.PictureBox WKP3;
        private System.Windows.Forms.PictureBox WKP4;
        private System.Windows.Forms.Label statusLabel;
    }
}

